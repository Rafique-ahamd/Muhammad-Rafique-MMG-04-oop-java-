import java.util.Scanner;
public class task05{
	   public static void main(String[] args) {
	Scanner Scanner = new Scanner(System.in);
	int rows = 5;
	int columns = 10;
	boolean[][] seats = new boolean[rows][columns];
	int choice;
	do {
		System.out.println("\n1.Display available seats");
		System.out.println("2.Reserve a seats");
		System.out.println("3. Exist");
		System.out.println("Enter your choice");
		choice = Scanner.nextInt();
		switch (choice){
			case 1:
			System.out.println("\nAvailable seats: ");
			for (int i =0; i < rows; i++ ) {
				for (int j =0; j <columns; j++) {
					if (!seats[i][j]) {
						System.out.println("[" +(i + 1) + "," +(j + 1) + "] ");
						
					}
					
				}
				
			}
			System.out.println();
		
		    break;
		    case 2:
		    System.out.println("Enter row number (1-" + rows + "): ");
		    int row = Scanner.nextInt() - 1;
		    System.out.println("Enter column number (1-" + columns + "): ");
		    int col = Scanner.nextInt() - 1;

		    if (row >= 0 && row < rows && col >= 0 && col <columns) {
		    	if (!seats[row][col]) {
		    		seats[row][col] = true;
		    		System.out.println("Seats Reserved successfully!");

		    	}else{
		    		System.out.println("Seats is already Reserved.");

		    	}
		    	
		    }else{
		    	System.out.println("Invalid seat. Please try again.");
		    }
		    break;
		    case 3:
		    System.out.println("Exiting the program. Thank you!");
		    break;
		    default :
		    System.out.println("Invalid choice. Please try again.");
		    break;
		}

	}while(choice != 3);
	Scanner.close();
	}
}