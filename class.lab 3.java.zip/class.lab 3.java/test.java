import java.util.Scanner;
class test{
  public static void main(String[]args){
char[] letter = {"b","c","d","f","g","h"};
for(int i=0; i<letter.length; i++){
system.out.println(letter[i]);
}
}
}