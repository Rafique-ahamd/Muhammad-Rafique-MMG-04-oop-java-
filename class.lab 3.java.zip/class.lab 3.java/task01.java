import java.util.Scanner;
public class task01{
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.print("Enter the start of the range:  ");
	int start =scanner.nextInt();
	System.out.print("Enter the end of the range:  ");
	int end = scanner.nextInt();
	System.out.println("Prime numbers from " + start + " to " + end + " : ");
	for (int num = start; num<=end; num++ ) {
		if (IsPrime(num)) {
			System.out.print(num + " ");

			
		}
		
	}
	scanner.close();

}
public static boolean IsPrime(int num){
	if (num < 2) return false;
	for (int i = 2; i<=num / 2; i++ ) {
		if (num % i == 0) return false;
			
		}
	 	return true;
	}
}