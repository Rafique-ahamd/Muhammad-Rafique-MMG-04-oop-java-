public class task04{
   public static void main(String[] args) {
	int [] array = { 1, 4, 9, 16, 25, 36, 49, 64,0};
	int sum = 0;
	int i = 1;
	while (i <array.length){
		if (array[i] % 2 !=0) {
			sum += array[i];
		}
		if (array[i] == 81) {
			break;
			
		}
		i++;
	}
	System.out.println("Sum of odd numbers(stopped at 81): " + sum);

	}
}

